package com.accesa.pricecomparator.service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.accesa.pricecomparator.dto.ShoppingBasketResponse;
import com.accesa.pricecomparator.dto.SubstituteProductDto;
import com.accesa.pricecomparator.entity.Discount;
import com.accesa.pricecomparator.entity.ProductPrice;
import com.accesa.pricecomparator.repository.DiscountRepository;
import com.accesa.pricecomparator.repository.ProductPriceRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BasketServiceImpl implements BasketService {
	
	private final ProductPriceRepository productRepo;
	private final DiscountRepository discountRepo;
	
	@Override
	public ShoppingBasketResponse evaluateBasket(List<String> productIds, LocalDate date) {
		Map<String, Map<String, Double>> storeItemPrices = new HashMap<>();
        Map<String, Double> storeTotals = new HashMap<>();

        for (String pid : productIds) {
            List<ProductPrice> prices = productRepo.findByProductIdAndDate(pid, date);

            for (ProductPrice price : prices) {
                double originalPrice = price.getPrice();

                // Apply discount if found
                Optional<Discount> discountOpt = discountRepo.findByProductIdAndStoreAndFromDateLessThanEqualAndToDateGreaterThanEqual(
                        price.getProductId(), price.getStore(), date, date);

                double discounted = discountOpt
                	    .map(d -> originalPrice * (1 - d.getPercentageOfDiscount() / 100.0))
                	    .orElse(originalPrice);

                double finalPrice = Math.round(discounted * 100.0) / 100.0;

                // Save item price per store
                storeItemPrices
                    .computeIfAbsent(price.getStore(), k -> new HashMap<>())
                    .put(pid, finalPrice);

                // Accumulate total
                storeTotals.merge(price.getStore(), finalPrice, Double::sum);
            }
        }

        // Find best store
        String bestStore = storeTotals.entrySet()
            .stream()
            .min(Map.Entry.comparingByValue())
            .map(Map.Entry::getKey)
            .orElse(null);

        ShoppingBasketResponse response = new ShoppingBasketResponse();
        response.setBestStore(bestStore);
        response.setBestTotal(storeTotals.getOrDefault(bestStore, 0.0));
        response.setTotalPerStore(storeTotals);
        response.setItemPricesPerStore(storeItemPrices);

        return response;
	}
	
	@Override
	public List<SubstituteProductDto> getSubstitutes(String productId, LocalDate date) {
	    ProductPrice base = productRepo.findFirstByProductIdAndDate(productId, date)
	            .orElseThrow(() -> new RuntimeException("Product not found on given date"));

	    List<ProductPrice> substitutes = productRepo.findSubstitutes(base.getCategory(), productId, date);

	    return substitutes.stream().map(p -> {
	        double basePrice = p.getPrice();
	        double quantity = p.getPackageQuantity();
	        String unit = p.getPackageUnit();

	        Optional<Discount> discount = discountRepo.findByProductIdAndStoreAndFromDateLessThanEqualAndToDateGreaterThanEqual(
	                p.getProductId(), p.getStore(), date, date);

	        double finalPrice = basePrice;
	        Double discountPercent = null;
	        boolean isDiscounted = false;

	        if (discount.isPresent()) {
	            discountPercent = discount.get().getPercentageOfDiscount();
	            finalPrice = Math.round(basePrice * (1 - discountPercent / 100.0) * 100.0) / 100.0;
	            isDiscounted = true;
	        }

	        // avoid division by 0
	        double valuePerUnit = quantity > 0
	                ? Math.round((finalPrice / quantity) * 100.0) / 100.0
	                : 0.0;

	        return new SubstituteProductDto(
	                p.getProductId(),
	                p.getProductName(),
	                p.getBrand(),
	                p.getStore(),
	                basePrice,
	                discountPercent,
	                isDiscounted ? finalPrice : null,
	                isDiscounted,
	                quantity,
	                unit,
	                valuePerUnit
	        );
	    }).sorted(Comparator.comparingDouble(dto -> dto.getValuePerUnit()))
	      .toList();
	}

}
