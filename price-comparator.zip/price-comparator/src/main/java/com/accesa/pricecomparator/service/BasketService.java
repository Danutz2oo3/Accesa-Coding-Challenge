package com.accesa.pricecomparator.service;

import java.time.LocalDate;
import java.util.List;

import com.accesa.pricecomparator.dto.ShoppingBasketResponse;
import com.accesa.pricecomparator.dto.SubstituteProductDto;

public interface BasketService {
	
	public abstract ShoppingBasketResponse evaluateBasket(List<String> productIds, LocalDate date);
	
	List<SubstituteProductDto> getSubstitutes(String productId, LocalDate date);
	
}
