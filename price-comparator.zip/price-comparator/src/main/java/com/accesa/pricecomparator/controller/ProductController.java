package com.accesa.pricecomparator.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.accesa.pricecomparator.dto.PricePointDto;

@RequestMapping("/api")
public interface ProductController {

	@GetMapping("/products/history")
    public List<PricePointDto> getPriceHistory(
        @RequestParam String productId,
        @RequestParam(required = false) String store,
        @RequestParam(required = false) String brand,
        @RequestParam(required = false) String category
    );
}
