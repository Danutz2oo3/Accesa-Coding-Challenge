package com.accesa.pricecomparator.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import com.accesa.pricecomparator.dto.PricePointDto;
import com.accesa.pricecomparator.service.ProductAnalyticsService;

import lombok.RequiredArgsConstructor;


@RestController
@RequiredArgsConstructor
public class ProductControllerImpl implements ProductController {

	private final ProductAnalyticsService analyticsService;
	
	@Override
	public List<PricePointDto> getPriceHistory(String productId, String store, String brand, String category) {
		return analyticsService.getPriceHistory(productId, store, brand, category);
	}

}
