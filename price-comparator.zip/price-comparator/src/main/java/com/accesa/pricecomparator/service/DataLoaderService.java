package com.accesa.pricecomparator.service;

public interface DataLoaderService {

    public abstract void loadAllProductCSVs();
    
}
