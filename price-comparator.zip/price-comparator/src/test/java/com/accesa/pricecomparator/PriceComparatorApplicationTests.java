package com.accesa.pricecomparator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceComparatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
